<?php
//listez ici les utilisateurs habilités : [ [ pseudo1, motdepasse1 ] ]
$utilisateurs = [ [ "matthieu", "toto" ] , [ "sandra", "titi" ] ];
?>